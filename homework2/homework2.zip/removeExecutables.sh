rm server
rm retriever