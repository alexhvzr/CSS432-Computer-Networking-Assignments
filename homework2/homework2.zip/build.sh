g++ -pthread -std=c++14 -o Server server.cpp
g++ -std=c++14 -o Retriever retriever.cpp
